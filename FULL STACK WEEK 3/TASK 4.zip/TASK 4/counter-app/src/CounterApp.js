import React, { useState } from "react";
import "./CounterApp.css";

// Reusable counter display component (props example)
function CounterDisplay({ count }) {
  return <h1 className="counter-value">Count: {count}</h1>;
}

// Main App
function CounterApp() {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  const handleDecrement = () => {
    setCount(count - 1);
  };

  const handleReset = () => {
    setCount(0);
  };

  return (
    <div className="page-wrapper">
      <header className="header">My Modern Counter App</header>

      <div className="container">
        <div className="counter-card">
          <CounterDisplay count={count} />

          <div className="button-group">
            <button className="btn increment" onClick={handleIncrement}>
              +
            </button>
            <button className="btn decrement" onClick={handleDecrement}>
              –
            </button>
            <button className="btn reset" onClick={handleReset}>
              Reset
            </button>
          </div>
        </div>
      </div>

      <footer className="footer">© 2025 Zainab Ali Khan</footer>
    </div>
  );
}

export default CounterApp;
