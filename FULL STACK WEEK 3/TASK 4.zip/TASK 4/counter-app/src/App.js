import React from "react";
import CounterApp from "./CounterApp";

function App() {
  return (
    <div>
      <CounterApp />
    </div>
  );
}

export default App;
