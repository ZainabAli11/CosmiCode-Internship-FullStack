import React, { useState, useEffect } from 'react';

function WelcomeMessage() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const darkestBlue = '#0B0C2A'; // Very dark blue

  const containerStyle = {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    background: darkestBlue,
    fontFamily: "'Poppins', sans-serif",
    color: '#ffffff',
  };

  const headerFooterStyle = {
    padding: '20px 0',
    textAlign: 'center',
    background: darkestBlue,
    color: '#ffffff',
    fontSize: '1.5rem',
    fontWeight: '300',
    letterSpacing: '2px',
    textTransform: 'uppercase',
    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
  };

  const footerStyle = {
    ...headerFooterStyle,
    borderTop: '1px solid rgba(255, 255, 255, 0.1)',
    borderBottom: 'none',
    fontSize: '1rem',
  };

  const mainStyle = {
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  const cardStyle = {
    background: 'rgba(255, 255, 255, 0.05)', // Very subtle glassy effect
    borderRadius: '16px',
    padding: '40px 30px',
    textAlign: 'center',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(6px)',
  };

  const headingStyle = {
    fontSize: '2.5rem',
    marginBottom: '15px',
    color: '#ffffff',
    fontWeight: '600',
  };

  const subtitleStyle = {
    fontSize: '1.2rem',
    marginBottom: '25px',
    color: '#ffffff',
    opacity: 0.8,
  };

  const timeStyle = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: '#ffffff',
  };

  return (
    <div style={containerStyle}>
      <header style={headerFooterStyle}>Welcome Portal</header>

      <main style={mainStyle}>
        <div style={cardStyle}>
          <h1 style={headingStyle}>Welcome</h1>
          <p style={subtitleStyle}>We're happy to see you here!</p>
          <h2 style={timeStyle}>{currentTime.toLocaleString()}</h2>
        </div>
      </main>

      <footer style={footerStyle}>© 2025 Welcome Portal. All rights reserved.</footer>
    </div>
  );
}

export default WelcomeMessage;
