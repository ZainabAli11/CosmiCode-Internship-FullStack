import React from "react";
import SimpleForm from "./SimpleForm";

function App() {
  return (
    <div>
      <SimpleForm />
    </div>
  );
}

export default App;
