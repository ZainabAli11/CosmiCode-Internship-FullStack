import React, { useState } from 'react';
import './SimpleForm.css';
import { FiUser, FiMail, FiMessageCircle, FiCheckCircle } from 'react-icons/fi';

const App = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const [showToast, setShowToast] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);

    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);

    setFormData({
      name: '',
      email: '',
      message: '',
    });
  };

  return (
    <div className="app-container">
      <header className="header">
        <h1>Simple Form</h1>
      </header>

      <main className="form-container">
        <form onSubmit={handleSubmit} className="simple-form">
          <h2 className="form-title">Contact Us</h2>

          <div className="form-group">
            <FiUser className="input-icon" />
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder=" "
              required
            />
            <label htmlFor="name">Name</label>
          </div>

          <div className="form-group">
            <FiMail className="input-icon" />
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder=" "
              required
            />
            <label htmlFor="email">Email</label>
          </div>

          <div className="form-group">
            <FiMessageCircle className="input-icon" />
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder=" "
              rows="4"
              required
            />
            <label htmlFor="message">Message</label>
          </div>

          <button type="submit" className="submit-button">
            Submit
          </button>

          {showToast && (
            <div className="toast">
              <FiCheckCircle className="toast-icon" />
              Message submitted successfully!
            </div>
          )}
        </form>
      </main>

      <footer className="footer">
        <p>© 2025 Simple Form App</p>
      </footer>
    </div>
  );
};

export default App;
